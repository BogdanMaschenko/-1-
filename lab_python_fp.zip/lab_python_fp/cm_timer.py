from contextlib import contextmanager
from time import time, sleep


@contextmanager
def cm_timer_1():
    start = time()
    try:
        yield
    finally:
        print(round(time() - start, 2))


class cm_timer_2(object):
    def __enter__(self):
        self.t = time()
        return self

    def __exit__(self, type, value, traceback):
        self.e = time()
        print(round(self.e - self.t, 2))


if __name__ == '__main__':
    with cm_timer_1():
        sleep(5.5)

    with cm_timer_2():
        sleep(5.5)
