from random import randint


def get_random(num_count, begin, end):
    return ', '.join(str(randint(begin, end)) for i in range(num_count))


print(get_random(5, 1, 3))