def print_result(f):
    def decorated(*args, **kwargs):
        result_f = f(*args, **kwargs)
        print(f.__name__)
        if isinstance(result_f, list):
            print('\n'.join(map(str, result_f)))
        elif isinstance(result_f, dict):
            print('\n'.join(f'{i} = {result_f[i]}' for i in result_f))
        else:
            print(result_f)
        return f(*args, **kwargs)
    return decorated


@print_result
def test_1():
    return 1


@print_result
def test_2():
    return 'iu5'


@print_result
def test_3():
    return {'a': 1, 'b': 2}


@print_result
def test_4():
    return [1, 2]


if __name__ == '__main__':
    test_1()
    test_2()
    test_3()
    test_4()
