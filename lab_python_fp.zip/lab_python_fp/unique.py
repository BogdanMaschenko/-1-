class Unique(object):
    def __init__(self, items, **kwargs):
        kwargs['ignore_case'] = kwargs.setdefault('ignore_case', False)
        self.kwargs = kwargs
        self.items = items
        self.s = []
        for i in self.items:
            if isinstance(i, str) and self.kwargs['ignore_case']:
                if i.upper() not in self.s and i.lower() not in self.s:
                    self.s.append(i)
            elif i not in self.s:
                self.s.append(i)

    def __next__(self):
        assert len(self.s) > 0, 'итератор пуст'
        return self.s.pop(0)

    def __iter__(self):
        return self


data = ['a', 'A', 'b', 'B', 'a', 'A', 'b', 'B']
a = Unique(data)
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
