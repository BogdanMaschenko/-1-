goods = [
    {'title': 'Ковер', 'price': 2000, 'color': 'green'},
    {'title': 'Диван для отдыха', 'price': 5300, 'color': 'black'},
    {'price': None}]


def field(items, *args):
    assert len(args) > 0
    if len(args) == 1:
        return ', '.join(i.get(args[0]) for i in items if i.get(args[0]))
    result = [{i: j.get(i) for i in args if j.get(i)} for j in items]
    result = [str(i) for i in result if i]
    return ', '.join(result)


print(field(goods, 'title'))
print(field(goods, 'title', 'price'))
