from behave import *
from sorter import sort_by_absolute_value, sort_by_absolute_value_lambda

@given('a list of numbers: {numbers}')
def step_impl(context, numbers):
    context.data = eval(numbers)

@when('I sort them by absolute value')
def step_impl(context):
    context.result = sort_by_absolute_value(context.data)

@when('I sort them by absolute value in ascending order')
def step_impl(context):
     context.result = sort_by_absolute_value(context.data, reverse=False)

@when('I sort them by absolute value using lambda function')
def step_impl(context):
    context.result = sort_by_absolute_value_lambda(context.data)

@when('I sort them by absolute value in ascending order using lambda function')
def step_impl(context):
     context.result = sort_by_absolute_value_lambda(context.data, reverse=False)

@then('the result should be: {expected}')
def step_impl(context, expected):
    assert context.result == eval(expected)