def sort_by_absolute_value(data, reverse=True):
    return sorted(data, key=abs, reverse=reverse)


def sort_by_absolute_value_lambda(data, reverse=True):
    return sorted(data, key=lambda x: abs(x), reverse=reverse)


if __name__ == '__main__':
    data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]
    result = sort_by_absolute_value(data)
    print(result)

    result_with_lambda = sort_by_absolute_value_lambda(data)
    print(result_with_lambda)