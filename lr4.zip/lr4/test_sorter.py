import unittest
from sorter import sort_by_absolute_value, sort_by_absolute_value_lambda


class TestSorter(unittest.TestCase):
    def test_sort_positive_and_negative(self):
        data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]
        expected = [123, 100, -100, -30, 30, 4, -4, 1, -1, 0]
        self.assertEqual(sort_by_absolute_value(data), expected)

    def test_sort_already_sorted(self):
        data = [5, 4, 3, 2, 1]
        expected = [5, 4, 3, 2, 1]
        self.assertEqual(sort_by_absolute_value(data), expected)

    def test_sort_reverse_false(self):
        data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]
        expected = [0, 1, -1, 4, -4, -30, 30, 100, -100, 123]
        self.assertEqual(sort_by_absolute_value(data, reverse=False), expected)

    def test_sort_positive_and_negative_lambda(self):
        data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]
        expected = [123, 100, -100, -30, 30, 4, -4, 1, -1, 0]
        self.assertEqual(sort_by_absolute_value_lambda(data), expected)

    def test_sort_already_sorted_lambda(self):
        data = [5, 4, 3, 2, 1]
        expected = [5, 4, 3, 2, 1]
        self.assertEqual(sort_by_absolute_value_lambda(data), expected)

    def test_sort_reverse_false_lambda(self):
        data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]
        expected = [0, 1, -1, 4, -4, -30, 30, 100, -100, 123]
        self.assertEqual(sort_by_absolute_value_lambda(data, reverse=False), expected)
